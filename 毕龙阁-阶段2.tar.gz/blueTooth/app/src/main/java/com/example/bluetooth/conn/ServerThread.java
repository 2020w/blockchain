package com.example.bluetooth.conn;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;

import java.util.UUID;

public class ServerThread extends Thread{

    private static final String NAME = "BlueTooth_Server"; // 服务器名称
    private static final UUID MY_UUID = UUID.fromString(Constant.CONNECTTION_UUID); // 蓝牙UUID
    private final BluetoothServerSocket serverSocket;
    private final BluetoothAdapter bluetoothAdapter;
    private final Handler handler; // UI通信

    private ConnectedThread connectedThread; // 专门用于通信的线程

    public ServerThread(BluetoothAdapter bluetoothAdapter, Handler handler) {
        this.bluetoothAdapter = bluetoothAdapter;
        this.handler = handler;

        BluetoothServerSocket tmp = null;
        try
        {
            tmp = bluetoothAdapter.listenUsingInsecureRfcommWithServiceRecord(NAME, MY_UUID); // 服务器socket
        }
        catch (Exception e)
        {}
        serverSocket = tmp;
    }

    @Override
    public void run() {
        super.run();
        BluetoothSocket socket = null;
        while (true) {
            try {
                handler.sendEmptyMessage(Constant.MSG_START_LISTENING);
                socket = serverSocket.accept(); // 和传统socket不同，蓝颜不需要bind和listen，只需要accept就可以
            }
            catch (Exception e){
                handler.sendMessage(handler.obtainMessage(Constant.MSG_ERROR, e));
                break;
            }
            if(socket != null){
                // 处理连接到的accept的socket
                manageConnectedSocket(socket);
                try {
                    serverSocket.close();
                    handler.sendEmptyMessage(Constant.MSG_FINISH_LISTENING);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }

    // 处理接收到的socket
    private void manageConnectedSocket(BluetoothSocket socket)
    {
        if(connectedThread != null)
        {
            connectedThread.cancel();
        }
        handler.sendEmptyMessage(Constant.MSG_GOT_A_CLINET);
        connectedThread = new ConnectedThread(socket, handler);
        connectedThread.start();
    }

    public void cancle()
    {
        try{
            serverSocket.close();
            handler.sendEmptyMessage(Constant.MSG_FINISH_LISTENING);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public void sendData(byte[] data)
    {
        if(connectedThread != null)
            connectedThread.write(data);
    }
}
