package com.example.bluetooth;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;

import java.util.ArrayList;
import java.util.List;

// 蓝牙适配器
public class BlueToothController {

    // BluetoothAdapter这个类代表的是本机的蓝牙
    private BluetoothAdapter bluetoothAdapter;

    public BlueToothController() {
        this.bluetoothAdapter =  BluetoothAdapter.getDefaultAdapter();
    }

    public BluetoothAdapter getBluetoothAdapter() {
        return bluetoothAdapter;
    }

    public void setBluetoothAdapter(BluetoothAdapter bluetoothAdapter) {
        this.bluetoothAdapter = bluetoothAdapter;
    }

    // 判断手机是否支持蓝牙
    public boolean isSupportBlueTooth()
    {
        if(bluetoothAdapter != null)
            return true;
        else
            return false;
    }

    // 获取蓝牙状态
    public boolean getBlueToothStatus()
    {
        assert (this.bluetoothAdapter != null);
        return this.bluetoothAdapter.isEnabled();
    }

    // 打开蓝牙
    public void openBlueTooth(Activity activity, int requestCode)
    {
        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        activity.startActivityForResult(intent, requestCode);
        // bluetoothAdapter.enable();// 不推荐这种方式打开蓝牙
    }

    // 打开蓝牙的可见性，可以被其他设备发现
    public void openVisibly(Context context)
    {
        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        intent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        context.startActivity(intent);
    }

    // 关闭蓝牙
    public void closeBlueTooth()
    {
        bluetoothAdapter.disable();
    }

    // 查找设备
    public void findDevice()
    {
        assert (bluetoothAdapter != null);
        bluetoothAdapter.startDiscovery();
    }

    // 获取绑定设备
    public List<BluetoothDevice> getBondedDeviceList()
    {
        return new ArrayList<BluetoothDevice>(bluetoothAdapter.getBondedDevices());
    }
}
