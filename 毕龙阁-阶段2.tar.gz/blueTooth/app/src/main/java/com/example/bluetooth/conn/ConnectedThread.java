package com.example.bluetooth.conn;

import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class ConnectedThread extends Thread {
    private final BluetoothSocket blueToothSocket;
    private final InputStream inpuStream;
    private final OutputStream outStream;
    private final Handler handler;

    public ConnectedThread(BluetoothSocket socket, Handler handler) {
        this.blueToothSocket = socket;
        InputStream tmpIn = null;
        OutputStream tmpOut = null;
        this.handler = handler;
        // 使用临时对象获取输入和输出流，因为成员流是最终的
        try {
            tmpIn = socket.getInputStream();
            tmpOut = socket.getOutputStream();
        } catch (IOException e) { }

        inpuStream = tmpIn;
        outStream = tmpOut;
    }


    public void run() {
        byte[] buffer = new byte[1024];  // 用于流的缓冲存储
        int bytes; // 从read()返回bytes

        // 持续监听InputStream
        while (true) {
            try {

                // 从InputStream读取数据
                bytes = inpuStream.read(buffer);
                // 将获得的bytes发送到UI层activity
                if( bytes >0) {
                    Message message = handler.obtainMessage(Constant.MSG_GOT_DATA, new String(buffer, 0, bytes, "utf-8"));
                    handler.sendMessage(message);
                }
                Log.d("GOTMSG", "message size" + bytes);
            } catch (IOException e) {
                handler.sendMessage(handler.obtainMessage(Constant.MSG_ERROR, e));
                break;
            }
        }
    }

    /**
     * 在main中调用此函数，将数据发送到远端设备中
     */
    public void write(byte[] bytes) {
        try {
            outStream.write(bytes);
        } catch (IOException e) { }
    }

    /**
     * 在main中调用此函数，断开连接
     */
    public void cancel() {
        try {
            blueToothSocket.close();
        } catch (IOException e) { }
    }
}
