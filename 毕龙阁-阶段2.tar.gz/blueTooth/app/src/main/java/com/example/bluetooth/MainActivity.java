package com.example.bluetooth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.bluetooth.conn.ClientThread;
import com.example.bluetooth.conn.Constant;
import com.example.bluetooth.conn.ServerThread;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public static final int ACCESS_LOCATION = 2;

    Button btn_openVisibly, btn_find_device, btn_bonded_device, btn_start_listening;

    // 设备列表
    private List<BluetoothDevice> deviceList = new ArrayList<BluetoothDevice>();

    private Handler handler = new MyHandler();

    // 已绑定设备列表
    private List<BluetoothDevice> bondedDeviceList = new ArrayList<BluetoothDevice>();

    // 本机蓝牙的控制器
    private BlueToothController blueToothController = new BlueToothController();

    // listView控件
    private ListView item_list;

    private DeviceAdapter deviceAdapter;

    // 服务器socke
    private ServerThread serverThread;

    // 客户机socket
    private ClientThread clientThread;

    // 广播
    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            // 开始查找，初始化
            if(BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action))
            {
                setProgressBarIndeterminateVisibility(true); // 进度条
                deviceList.clear();
                deviceAdapter.notifyDataSetChanged(); // 通知adpter更新数据
                show_Toast("正在初始化蓝牙");
            }
            // 查找结束
            else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action))
            {
                setProgressBarIndeterminateVisibility(false); // 隐藏进度条
            }
            // 查找设备，初始化结束之后
            else if(BluetoothDevice.ACTION_FOUND.equals(action))
            {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                // 将发现的设备添加到列表
                deviceList.add(device);
                deviceAdapter.notifyDataSetChanged(); // 通知adpter更新数据
            }
            // 设备扫描模式改变
            else if(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED.equals(action))
            {
                int scanMode = intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, 0);
                if( scanMode == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) // 可发现
                {
                    setProgressBarIndeterminateVisibility(true); // 打开进度条
                }
                else
                {
                    setProgressBarIndeterminateVisibility(false);
                }
            }
            // 绑定状态改变
            else if(BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action))
            {
                BluetoothDevice remoteDevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if(remoteDevice == null)
                {
                    show_Toast("没有设备");
                    return;
                }
                int status = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, 0);
                if(status == BluetoothDevice.BOND_BONDED)
                {
                    show_Toast("绑定结束:" + remoteDevice.getName());
                }
                else if(status == BluetoothDevice.BOND_BONDING)
                {
                    show_Toast("正在绑定:" + remoteDevice.getName());
                }
                else if(status == BluetoothDevice.BOND_NONE)
                {
                    show_Toast("没有绑定" + remoteDevice.getName());
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 获取权限
        getPermission();

        // 监听广播
        IntentFilter intentFilter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        // 开始查找
        intentFilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        // 查找结束
        intentFilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        // 查找设备
        intentFilter.addAction(BluetoothDevice.ACTION_FOUND);
        // 设备扫描模式改变
        intentFilter.addAction(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        // 绑定状态改变
        intentFilter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);

        registerReceiver(broadcastReceiver, intentFilter);

        // 打开本机蓝牙
        blueToothController.openBlueTooth(this, 0);

        init_UI();

    }

    private void init_UI()
    {
        // 使用listView展示数据
        item_list = (ListView)findViewById(R.id.item_list);
        deviceAdapter = new DeviceAdapter(deviceList, this);

        btn_openVisibly = (Button)findViewById(R.id.btn_openVisibly);
        btn_find_device = (Button)findViewById(R.id.btn_find_device);
        btn_bonded_device = (Button)findViewById(R.id.btn_bonded_device);
        btn_start_listening = (Button)findViewById(R.id.btn_start_listening);


        btn_openVisibly.setOnClickListener(this);
        btn_find_device.setOnClickListener(this);
        btn_bonded_device.setOnClickListener(this);
        btn_start_listening.setOnClickListener(this);

        item_list.setAdapter(deviceAdapter);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_openVisibly)
        {
            // 打开可见性
            blueToothController.openVisibly(this);
        }
        else if(v.getId() == R.id.btn_find_device)
        {
            // 发现设备
            deviceAdapter.refresh(deviceList);
            blueToothController.findDevice();
            item_list.setOnItemClickListener(bindDevice); // 绑定未连接的蓝牙
        }
        else if(v.getId() == R.id.btn_bonded_device)
        {
            // 查看已经绑定的设备
            bondedDeviceList = blueToothController.getBondedDeviceList();
            deviceAdapter.refresh(bondedDeviceList);
            item_list.setOnItemClickListener(bindedDevice); // 已绑定的蓝牙，创建通信连接
        }
        else if(v.getId() == R.id.btn_start_listening)
        {
            if(serverThread != null)
            {
                serverThread.cancle();
            }
            serverThread = new ServerThread(blueToothController.getBluetoothAdapter(),  handler);
            serverThread.start();
        }

    }

    // 未连接-->已连接
    private AdapterView.OnItemClickListener bindDevice = new AdapterView.OnItemClickListener() {
        @TargetApi(Build.VERSION_CODES.KITKAT)
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            BluetoothDevice device = deviceList.get(i);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                device.createBond();
            }
        }
    };

    // 已连接-->建立通信socket
    private AdapterView.OnItemClickListener bindedDevice = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            BluetoothDevice device = bondedDeviceList.get(i);
            if (clientThread != null) {
                clientThread.cancel();
            }
            clientThread = new ClientThread(device, blueToothController.getBluetoothAdapter(), handler);
            clientThread.start();
        }
    };

    private class MyHandler extends Handler {

        public void handleMessage(Message message) {
            super.handleMessage(message);
            switch (message.what) {
                case Constant.MSG_GOT_DATA:
                    show_Toast("data:" + String.valueOf(message.obj));
                    break;
                case Constant.MSG_ERROR:
                    show_Toast("error:" + String.valueOf(message.obj));
                    break;
                case Constant.MSG_CONNECTED_TO_SERVER:
                    show_Toast("连接到服务端");
                    break;
                case Constant.MSG_GOT_A_CLINET:
                    show_Toast("找到服务端");
                    break;
            }
        }
    }

    private void show_Toast(String msg)
    {
        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
    }

    // 以下三个方法是获取发现蓝牙权限所添加的
    @SuppressLint("WrongConstant")
    private void getPermission() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            int permissionCheck = 0;
            permissionCheck = this.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION);
            permissionCheck += this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION);
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                this.requestPermissions( // 请求授权
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION},
                        ACCESS_LOCATION);// 自定义常量,任意整型
            } else {
                // 已经获得权限
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case ACCESS_LOCATION:
                if (hasAllPermissionGranted(grantResults)) {
                    show_Toast("onRequestPermissionsResult: OK");
                } else {
                    show_Toast("onRequestPermissionsResult: NOT OK");
                }
                break;
        }
    }

    private boolean hasAllPermissionGranted(int[] grantResults) {
        for (int grantResult : grantResults) {
            if (grantResult == PackageManager.PERMISSION_DENIED) {
                return false;
            }
        }
        return true;
    }
}
