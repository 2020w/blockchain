package com.example.bluetooth;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class DeviceAdapter extends BaseAdapter {

    private List<BluetoothDevice> diviceList;
    private Context context;

    public DeviceAdapter(List<BluetoothDevice> diviceList, Context context) {
        this.diviceList = diviceList;
        this.context = context;
    }

    @Override
    public int getCount() {
        return diviceList.size();
    }

    @Override
    public Object getItem(int position) {
        return diviceList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View itemView = convertView;

        // 复用view，性能优化
        if(itemView == null)
        {
            itemView = LayoutInflater.from(context).inflate(R.layout.activety_item, null, false);
        }
        TextView line1 = (TextView)itemView.findViewById(R.id.text1);
        TextView line2 = (TextView)itemView.findViewById(R.id.text2);

        // 获取对应的蓝牙设备
        BluetoothDevice bluetoothDevice = (BluetoothDevice)getItem(position);

        // 显示设备名
        line1.setText(bluetoothDevice.getName());
        // 显示地址
        line2.setText(bluetoothDevice.getAddress());

        return itemView;
    }

    public void refresh(List<BluetoothDevice> diviceList)
    {
        this.diviceList = diviceList;
        notifyDataSetChanged(); // 通知刷新
    }
}
