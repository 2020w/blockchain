// mongodb 连接
var MongoClient = require('mongodb').MongoClient
var url = 'mongodb://localhostl:27017'
var dbName = 'test'

// 数据库连接方法封装。
function connect(callback)
{
	MongoClient.connect(url, function(err, client)
	{
		if(err)
		{
			console.log('数据库连接错误', err)
		}
		else
		{
			var db = client.db(dbName)
			callback && callback(db)
			client.close()
		}
	}
)}

// 提供连接方法
module.exports = {
	connect
}