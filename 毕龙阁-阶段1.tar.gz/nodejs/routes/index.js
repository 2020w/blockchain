var express = require('express');
var router = express.Router();
//var model = require('../model'); //使用数据库连接方法

/* GET home page. */
router.get('/', function(req, res, next) {
  // model.connect(function(db){
  // 	db.collection('users').find().toArray(function(err, docs){
  // 		console.log('用户列表', docs)
  		
  // })
  res.render('index', { title: 'Express' });
});

// 注册页面
router.get('/regist',function(req, res, next){
	res.render('regist', {});
});


// 登录页面
router.get('/login',function(req, res, next){
	res.render('login', {});
});

module.exports = router;
