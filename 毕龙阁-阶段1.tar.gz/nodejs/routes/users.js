var express = require('express');
var router = express.Router();
var model = require('../model'); //使用数据库模块
/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

// 注册
router.post('/regist', function(req, res, next){
	var data = {
		username: req.body.userName,
		password: req.body.password,
		password2: req.body.password2
	}
	model.connect(function(db){
		db.collection('users').insertOne(data, function(err, ret){ //ret接受插入结果
			if(err)
			{
				console.log('注册失败');
				res.redirect('/regist'); //重定向
			}
			else
			{
				res.redirect('/login'); //重定向
			}
		})
	})
	// res.send(data);  //send只返回数据，redirect表示重定向，render返回页面并且返回数据
});


// 登录
router.post('/login', function(req, res, next){
	var data = {
		username: req.body.userName,
		password: req.body.password
	}
	model.connect(function(db){
		db.collection('users').find(data).toArray(function(err, docs) { // 数据存在docs变量中
			if(err)
			{
				res.redirect('/login');
			}
			else
			{
				if(docs.length > 0)
				{
					res.redirect('/'); //登录成功，进入首页
				}
				else
				{
					res.redirect('/login'); //登录失败返回登录页面
				}
			}
		})
	})
}

module.exports = router;
